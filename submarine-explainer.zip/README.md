# Nuclear Submarine Explainer — Remotion 3D Short (1080×1920, 30 fps)

Procedural Three.js submarine (no external models) rendered through Remotion.
Your supplied voiceover (`public/audio/voiceover.m4a`) is the master timeline; nothing is re-timed or replaced.

## Render from your Android phone (GitHub Actions)
1. Create a GitHub repo, upload **all files of this ZIP** (the web UI / GitHub mobile app both work).
2. Open **Actions → "Render submarine explainer" → Run workflow**.
3. When it finishes, open the run and download the artifact **submarine-short** (`submarine.mp4`).
   The workflow renders one still first (`check.png`) so a WebGL problem fails fast.
Expect a long render (software WebGL on a CPU runner): plan on roughly 1–4 hours. The job limit is set to 5 h.

## Timeline (seconds, snapped to the dips in your audio)
| Scene | Time | Narration | What is on screen |
|---|---|---|---|
| 1 | 0.2–4.9 | "stay underwater for months" | exterior hero, bow → sail |
| 2 | 5.0–10.97 | tiny nuclear reactor, heat | hull cutaway sweep, reactor macro, glowing core |
| 3a | 11.0–13.4 | heat → high-pressure steam | steam generator, steam flow |
| 3b | 13.5–17.1 | spins powerful turbines | HP/LP turbines spin up |
| 3c | 17.2–19.15 | energy to move the sub | reduction gear → shaft → propeller |
| 4 | 19.2–22.9 | ballast tanks | whip-pan, vents open, tanks flood, sub dives |
| 5 | 23.0–28.6 | sonar | sonar sphere pings (23.1/24.5/25.9/27.3), rocks light up |
| 6 | 28.7–33.7 | no air, no sunlight, nuclear power | darkness, reactor surge, final pull-back, hit at 33.0 |

Pauses at 13.4 / 17.1 / 25.2 / 29.4 s were measured from your file (`python3 scripts/analyze_voice.py`).
The first four sentence boundaries (≈4.9, 10.97, 19.2, 22.9) were inferred from energy dips plus syllable counts
because no speech-to-text was available — **if a cut feels early/late, edit the numbers in `src/timeline.json`
and the keyframe times in `src/camera.ts`**; `scripts/generate_audio.py` reads the same JSON.

## Files
- `src/timeline.json` – single source of timing (video + audio generator)
- `src/camera.ts` – camera keyframes (Hermite spline) + sub dive pose
- `src/world/` – procedural geometry: `hull.ts` (hull, cutaway, ballast, sonar, interior), `machinery.ts` (reactor, steam generator, turbines, condenser, reduction gear, shaft, propeller, flows), `environment.ts` (seabed, rocks, marine snow, light shafts, bubbles), `world.ts` (lights, fog, assembly)
- `src/Overlay.tsx` – small component tags pinned to the 3D parts (no captions), kept inside Shorts safe zones
- `scripts/generate_audio.py` – original music + SFX + sidechain ducking + mix checks → `public/audio/music.wav`, `sfx.wav`, `reports/`
- `reports/mix_preview.mp3` – listen to the intended final mix on your phone

## Audio
`python3 scripts/generate_audio.py` (needs numpy, scipy, ffmpeg) regenerates the music/SFX. Voice gain 0.75 (your file peaks at 0 dBFS).
Last generated mix: music ≈12.5 dB and SFX ≈13.5 dB below the voice, summed peak −2.3 dBFS, 0 clipped samples (`reports/audio_report.json`).

## Local commands
`npm install` · `npm run studio` · `npm run typecheck` · `npm run render`

## Verification status (honest)
Done offline: audio generation and level checks; timeline analysis; TypeScript parse/semantic check against loose stubs.
**Not done:** `npm install`, full TypeScript check against the real `three`/Remotion types, and any visual render — the build
sandbox has no internet. The 3D scenes have therefore never been seen by me; expect to tune camera framing and materials after
the first render. Remotion versions are caret ranges (`^4.0.250`); if install complains, set all `remotion`/`@remotion/*` to one identical version.
