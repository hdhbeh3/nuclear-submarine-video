import timeline from "./timeline.json";

export const TL = timeline;
export const C = timeline.cues;
export const FPS = timeline.fps;
/** Matches the supplied voiceover (33.91 s) + a 20 ms tail so the last word is never cut. */
export const DURATION_FRAMES = Math.ceil((timeline.voiceDuration + 0.02) * FPS);

export const clamp = (x: number, a = 0, b = 1): number => Math.min(b, Math.max(a, x));
export const ramp = (t: number, a: number, b: number): number => clamp((t - a) / (b - a));
export const smooth = (x: number): number => {
  const c = clamp(x);
  return c * c * (3 - 2 * c);
};
export const smoother = (x: number): number => {
  const c = clamp(x);
  return c * c * c * (c * (c * 6 - 15) + 10);
};
export const lerp = (a: number, b: number, k: number): number => a + (b - a) * k;
/** deterministic pseudo random in [0,1) */
export const rand = (seed: number): number => {
  const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};
export const frac = (x: number): number => x - Math.floor(x);

/** Light level of the ocean (1 = sunlit shallows, ~0 = pitch dark). Follows the narration. */
export const lightLevel = (t: number): number => {
  let L = 1;
  L -= 0.5 * smooth(ramp(t, 20.3, 23.5)); // diving (ballast)
  L -= 0.25 * smooth(ramp(t, 23.5, 28.7)); // darkness of the ocean (sonar)
  L -= 0.2 * smooth(ramp(t, C.darkenStart, 29.9)); // "No air. No sunlight."
  return Math.max(0.03, L);
};

/** Glow of the reactor core (1 = normal operation, >1 = finale surge). */
export const coreGlow = (t: number): number => {
  const warm = 0.25 + 0.75 * smooth(ramp(t, 5.2, 10.8));
  const finale = 0.9 * smooth(ramp(t, C.nuclearPower, C.finalHit));
  const beat = t > C.nuclearPower ? 0.12 * Math.pow(Math.max(0, Math.sin(((t - C.nuclearPower) / 0.8) * Math.PI * 2)), 4) : 0;
  return warm + finale + beat;
};
