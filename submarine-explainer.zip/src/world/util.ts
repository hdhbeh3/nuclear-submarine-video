import * as THREE from "three";

export type P3 = [number, number, number];

export const mesh = (
  parent: THREE.Object3D,
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
): THREE.Mesh => {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  parent.add(m);
  return m;
};

/** Cylinder whose axis runs along X (top radius ends up at -X). */
export const cylX = (rTop: number, rBot: number, len: number, seg = 32, open = false): THREE.CylinderGeometry => {
  const g = new THREE.CylinderGeometry(rTop, rBot, len, seg, 1, open);
  g.rotateZ(Math.PI / 2);
  return g;
};

export const tube = (pts: P3[], r: number, mat: THREE.Material, parent: THREE.Object3D): THREE.CatmullRomCurve3 => {
  const curve = new THREE.CatmullRomCurve3(
    pts.map((p) => new THREE.Vector3(p[0], p[1], p[2])),
    false,
    "centripetal",
  );
  const geo = new THREE.TubeGeometry(curve, Math.max(24, pts.length * 16), r, 14, false);
  mesh(parent, geo, mat);
  return curve;
};

/** Integrates an angular-speed function into a cheap lookup table angle(t). */
export const makeAngle = (omega: (t: number) => number, tMax = 36, step = 1 / 120): ((t: number) => number) => {
  const n = Math.ceil(tMax / step) + 2;
  const table = new Float64Array(n);
  for (let i = 1; i < n; i++) table[i] = table[i - 1] + omega((i - 0.5) * step) * step;
  return (t: number) => {
    const f = Math.max(0, Math.min(n - 2, t / step));
    const i = Math.floor(f);
    return table[i] + (table[i + 1] - table[i]) * (f - i);
  };
};

/** Soft round sprite texture (glow / bubble). */
export const softDot = (inner = 0.0, size = 128): THREE.CanvasTexture => {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const g = c.getContext("2d") as CanvasRenderingContext2D;
  const grd = g.createRadialGradient(size / 2, size / 2, size * inner, size / 2, size / 2, size / 2);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.35, "rgba(255,255,255,0.45)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  return tex;
};
