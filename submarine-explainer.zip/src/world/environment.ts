import * as THREE from "three";
import { C, frac, lightLevel, ramp, rand, smooth } from "../timing";
import { mesh, softDot, P3 } from "./util";

export const DRIFT = 2.2; // world drifts toward the stern at this speed -> the sub "cruises" forward

const fbm = (x: number, z: number): number => {
  let a = 0;
  let amp = 1;
  let f = 0.012;
  for (let i = 0; i < 5; i++) {
    a += amp * (Math.sin(x * f * 1.7 + i * 1.3) * Math.cos(z * f * 1.3 - i * 2.1) + 0.5 * Math.sin((x + z) * f * 2.3 + i));
    amp *= 0.5;
    f *= 2.07;
  }
  return a;
};

export type SonarRock = { mesh: THREE.Mesh; mat: THREE.MeshStandardMaterial };

export type EnvRig = {
  group: THREE.Group; // drifting content (seabed, rocks)
  rocks: SonarRock[];
  update: (t: number, subY: number) => void;
};

export const buildEnvironment = (): EnvRig => {
  const root = new THREE.Group();
  const drift = new THREE.Group();
  root.add(drift);

  // ---------------- seabed
  const SEA_Y = -17;
  const geo = new THREE.PlaneGeometry(380, 260, 190, 130);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.getAttribute("position") as THREE.BufferAttribute;
  const col = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const h = fbm(x, z) * 2.4 + 0.25 * Math.sin(x * 0.6) * Math.sin(z * 0.5);
    pos.setY(i, h);
    const k = Math.min(1, Math.max(0, 0.5 + h * 0.12));
    col[i * 3] = 0.16 + 0.18 * k;
    col[i * 3 + 1] = 0.2 + 0.17 * k;
    col[i * 3 + 2] = 0.2 + 0.14 * k;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  geo.computeVertexNormals();
  const seaMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0, envMapIntensity: 0.2 });
  const sea = mesh(drift, geo, seaMat, 40, SEA_Y, 0);
  sea.receiveShadow = true;

  // ---------------- rocks / spires (they glow when the sonar pings reach them)
  const rocks: SonarRock[] = [];
  for (let i = 0; i < 16; i++) {
    const g = new THREE.IcosahedronGeometry(1, 2);
    const p = g.getAttribute("position") as THREE.BufferAttribute;
    for (let v = 0; v < p.count; v++) {
      const n = 1 + 0.28 * Math.sin(p.getX(v) * 3.1 + i) * Math.cos(p.getY(v) * 2.7 + i * 2) + 0.12 * Math.sin(p.getZ(v) * 6 + i);
      p.setXYZ(v, p.getX(v) * n, p.getY(v) * n, p.getZ(v) * n);
    }
    g.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ color: 0x2c363a, roughness: 0.95, metalness: 0.05, emissive: 0x7fe9ff, emissiveIntensity: 0, envMapIntensity: 0.2 });
    const m = new THREE.Mesh(g, mat);
    const s = 2 + rand(i + 1) * 5;
    m.scale.set(s * (0.7 + rand(i + 9) * 0.8), s * (1.0 + rand(i + 4) * 1.8), s * (0.7 + rand(i + 5) * 0.8));
    const lx = 100 + rand(i + 20) * 70;
    const lz = (rand(i + 30) - 0.5) * 60;
    const ly = SEA_Y + fbm(lx - 40, lz) * 2.4 + m.scale.y * 0.5 - 1;
    m.position.set(lx, ly, lz);
    m.castShadow = false;
    drift.add(m);
    rocks.push({ mesh: m, mat });
  }

  // ---------------- marine snow
  const SN = 1100;
  const sg = new THREE.BufferGeometry();
  const base = new Float32Array(SN * 3);
  for (let i = 0; i < SN; i++) {
    base[i * 3] = rand(i * 3 + 1) * 180 - 70;
    base[i * 3 + 1] = rand(i * 3 + 2) * 60 - 30;
    base[i * 3 + 2] = rand(i * 3 + 3) * 90 - 35;
  }
  sg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(base), 3));
  const snowMat = new THREE.PointsMaterial({ color: 0xbfe8ff, size: 0.12, map: softDot(0), transparent: true, opacity: 0.55, depthWrite: false, sizeAttenuation: true });
  const snow = new THREE.Points(sg, snowMat);
  snow.frustumCulled = false;
  root.add(snow);

  // ---------------- volumetric light shafts (additive gradient planes)
  const rayTex = (() => {
    const c = document.createElement("canvas");
    c.width = 64;
    c.height = 256;
    const g = c.getContext("2d") as CanvasRenderingContext2D;
    const gx = g.createLinearGradient(0, 0, 64, 0);
    gx.addColorStop(0, "rgba(255,255,255,0)");
    gx.addColorStop(0.5, "rgba(255,255,255,1)");
    gx.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = gx;
    g.fillRect(0, 0, 64, 256);
    g.globalCompositeOperation = "destination-in";
    const gy = g.createLinearGradient(0, 0, 0, 256);
    gy.addColorStop(0, "rgba(0,0,0,1)");
    gy.addColorStop(0.7, "rgba(0,0,0,0.35)");
    gy.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gy;
    g.fillRect(0, 0, 64, 256);
    return new THREE.CanvasTexture(c);
  })();
  const rays: { m: THREE.Mesh; base: number; ph: number }[] = [];
  const rayMat = new THREE.MeshBasicMaterial({ map: rayTex, color: 0x7fd0ff, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
  for (let i = 0; i < 9; i++) {
    const w = 6 + rand(i + 50) * 9;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 80), rayMat);
    m.position.set(-45 + i * 12 + rand(i + 60) * 6, 18, -22 + (i % 3) * 9);
    m.rotation.set(0, rand(i + 70) * 0.8 - 0.4, 0.28 + rand(i + 80) * 0.1);
    root.add(m);
    rays.push({ m, base: 0.5 + rand(i + 90) * 0.5, ph: rand(i + 100) * 6 });
  }

  const update = (t: number, subY: number): void => {
    drift.position.x = -DRIFT * t;
    const L = lightLevel(t);
    // rays fade with depth/darkness
    rayMat.opacity = 0.2 * Math.pow(L, 1.6) * (1 - smooth(ramp(t, C.darkenStart, 29.6)));
    rays.forEach((r) => {
      r.m.rotation.z = 0.3 + 0.03 * Math.sin(t * 0.35 + r.ph);
      r.m.scale.x = 1 + 0.15 * Math.sin(t * 0.5 + r.ph);
    });
    // marine snow drifts toward the stern and sinks slowly
    const arr = (sg.getAttribute("position") as THREE.BufferAttribute).array as Float32Array;
    for (let i = 0; i < SN; i++) {
      const x = ((((base[i * 3] - 1.6 * t + 70) % 180) + 180) % 180) - 70;
      const y = ((((base[i * 3 + 1] - 0.25 * t + 30) % 60) + 60) % 60) - 30 + subY * 0.6;
      arr[i * 3] = x;
      arr[i * 3 + 1] = y;
      arr[i * 3 + 2] = base[i * 3 + 2];
    }
    (sg.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
    snowMat.opacity = 0.25 + 0.4 * L;
    // sonar pulse reaches the rocks -> they flash
    const origin = new THREE.Vector3(19.3, subY - 0.2, 0);
    const wp = new THREE.Vector3();
    for (const r of rocks) {
      r.mesh.getWorldPosition(wp);
      const d = wp.distanceTo(origin);
      let e = 0;
      for (const tp of C.sonarPings) {
        const age = t - tp;
        if (age < 0 || age > 3.5) continue;
        const R = 1.6 + 28 * age;
        e = Math.max(e, Math.exp(-Math.pow((d - R) / 2.6, 2)) * Math.max(0, 1 - age / 3.2));
      }
      r.mat.emissiveIntensity = 1.6 * e;
    }
  };
  return { group: root, rocks, update };
};

export type BubbleSpec = {
  origin: P3;
  vel: P3;
  spread: P3;
  count: number;
  life: [number, number];
  size: number;
  color: number;
  opacity: number;
};

export const buildBubbles = (spec: BubbleSpec): { points: THREE.Points; update: (t: number, intensity: number) => void } => {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(spec.count * 3), 3));
  const mat = new THREE.PointsMaterial({ color: spec.color, size: spec.size, map: softDot(0.15), transparent: true, opacity: 0, depthWrite: false, sizeAttenuation: true });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  const seeds = Array.from({ length: spec.count }, (_, i) => [rand(i * 5 + 1), rand(i * 5 + 2), rand(i * 5 + 3), rand(i * 5 + 4)]);
  const update = (t: number, intensity: number): void => {
    mat.opacity = spec.opacity * intensity;
    points.visible = intensity > 0.01;
    if (!points.visible) return;
    const arr = (geo.getAttribute("position") as THREE.BufferAttribute).array as Float32Array;
    for (let i = 0; i < spec.count; i++) {
      const [a, b, c, d] = seeds[i];
      const life = spec.life[0] + (spec.life[1] - spec.life[0]) * a;
      const age = frac(t / life + b) * life;
      const wob = Math.sin(age * 4 + c * 6.28) * 0.12;
      arr[i * 3] = spec.origin[0] + spec.vel[0] * age + (c - 0.5) * spec.spread[0] + wob;
      arr[i * 3 + 1] = spec.origin[1] + spec.vel[1] * age + (d - 0.5) * spec.spread[1];
      arr[i * 3 + 2] = spec.origin[2] + spec.vel[2] * age + (a - 0.5) * spec.spread[2] + wob;
    }
    (geo.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
  };
  return { points, update };
};
