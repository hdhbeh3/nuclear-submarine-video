import * as THREE from "three";

/** Shared cutaway plane: keeps everything with z <= constant. Animated by the world (reveal at 5.0-6.8 s). */
export const cutPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), 4);
/** Ballast-water plane: keeps y <= (constant). */
export const waterPlane = new THREE.Plane(new THREE.Vector3(0, -1, 0), -20);

type Opts = {
  metal?: number;
  rough?: number;
  emissive?: number;
  emissiveI?: number;
  side?: THREE.Side;
  clip?: boolean;
  opacity?: number;
  env?: number;
  map?: THREE.Texture | null;
  bump?: THREE.Texture | null;
  bumpScale?: number;
};

export const std = (color: number, o: Opts = {}): THREE.MeshStandardMaterial => {
  const m = new THREE.MeshStandardMaterial({
    color,
    metalness: o.metal ?? 0.5,
    roughness: o.rough ?? 0.5,
    side: o.side ?? THREE.DoubleSide,
    envMapIntensity: o.env ?? 0.7,
  });
  if (o.emissive !== undefined) {
    m.emissive = new THREE.Color(o.emissive);
    m.emissiveIntensity = o.emissiveI ?? 1;
  }
  if (o.opacity !== undefined) {
    m.transparent = true;
    m.opacity = o.opacity;
    m.depthWrite = false;
  }
  if (o.map) m.map = o.map;
  if (o.bump) {
    m.bumpMap = o.bump;
    m.bumpScale = o.bumpScale ?? 1;
  }
  if (o.clip !== false) {
    m.clippingPlanes = [cutPlane];
    m.clipShadows = true;
  }
  return m;
};

/** Procedural anechoic-tile / panel texture (grey values) used as bump + roughness variation. */
export const tileTexture = (repX: number, repY: number): THREE.CanvasTexture => {
  const S = 256;
  const c = document.createElement("canvas");
  c.width = S;
  c.height = S;
  const g = c.getContext("2d") as CanvasRenderingContext2D;
  g.fillStyle = "#808080";
  g.fillRect(0, 0, S, S);
  const n = 8;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const v = 112 + Math.floor(((Math.sin(i * 12.9898 + j * 78.233) * 43758.5453) % 1 + 1) % 1 * 36);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.fillRect((i * S) / n + 2, (j * S) / n + 2, S / n - 4, S / n - 4);
    }
  }
  g.strokeStyle = "#2a2a2a";
  g.lineWidth = 3;
  for (let i = 0; i <= n; i++) {
    g.beginPath();
    g.moveTo((i * S) / n, 0);
    g.lineTo((i * S) / n, S);
    g.stroke();
    g.beginPath();
    g.moveTo(0, (i * S) / n);
    g.lineTo(S, (i * S) / n);
    g.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repX, repY);
  return tex;
};
