import * as THREE from "three";
import { C, ramp, smooth, smoother } from "../timing";
import { mesh, cylX, P3 } from "./util";
import { std, tileTexture, cutPlane, waterPlane } from "./materials";

/** Hull dimensions (world units ~ metres/2). Bow = +x, stern = -x. */
export const HULL = { L: 23.5, RM: 3.4, RP: 2.1 };

export const outerR = (x: number): number => {
  const { RM } = HULL;
  if (x > 13) {
    const u = Math.min(1, (x - 13) / 10.5);
    return Math.max(0.001, RM * Math.pow(Math.max(0, 1 - Math.pow(u, 2.2)), 0.55));
  }
  if (x < -13) {
    const u = Math.min(1, (-13 - x) / 10.5);
    return 0.5 + (RM - 0.5) * Math.pow(Math.cos((u * Math.PI) / 2), 0.8);
  }
  return RM;
};

export const pressR = (x: number): number => {
  const { RP } = HULL;
  if (x < -14) {
    const u = Math.min(1, (-14 - x) / 5);
    return 0.7 + (RP - 0.7) * Math.pow(Math.cos((u * Math.PI) / 2), 0.9);
  }
  if (x > 13.5) {
    const u = Math.min(1, (x - 13.5) / 1.7);
    return Math.max(0.001, RP * Math.sqrt(Math.max(0, 1 - u * u)));
  }
  return RP;
};

const latheX = (fn: (x: number) => number, x0: number, x1: number, n: number, seg: number): THREE.LatheGeometry => {
  const pts: THREE.Vector2[] = [];
  for (let i = 0; i <= n; i++) {
    const x = x0 + ((x1 - x0) * i) / n;
    pts.push(new THREE.Vector2(Math.max(0.001, fn(x)), x));
  }
  const g = new THREE.LatheGeometry(pts, seg);
  g.rotateZ(-Math.PI / 2); // lathe axis (y) -> +x
  return g;
};

export const FWD_MBT: [number, number] = [5.8, 12.6];
export const AFT_MBT: [number, number] = [-12.6, -5.8];

export type HullRig = {
  group: THREE.Group;
  update: (t: number, subY: number) => void;
  ventLids: THREE.Mesh[];
  ventPositions: P3[];
};

export const buildHull = (): HullRig => {
  const g = new THREE.Group();
  const { RM, RP } = HULL;

  // ---------------- outer (hydrodynamic) hull: dark anechoic coating outside, pale teal paint inside
  const tiles = tileTexture(40, 90);
  const outerGeo = latheX(outerR, -HULL.L, HULL.L, 220, 72);
  const hullMat = std(0x1e272d, { metal: 0.35, rough: 0.55, side: THREE.FrontSide, bump: tiles, bumpScale: 0.6, env: 0.9 });
  const hull = mesh(g, outerGeo, hullMat);
  hull.castShadow = true;
  const linerMat = std(0x78a2b3, { metal: 0.2, rough: 0.7, side: THREE.BackSide });
  const liner = mesh(g, outerGeo, linerMat);
  liner.scale.set(1, 0.994, 0.994);

  // ---------------- pressure hull (steel) : outside seen in ballast bands, inside = compartments
  const pGeo = latheX(pressR, -19, 15.2, 160, 64);
  mesh(g, pGeo, std(0x5f6c72, { metal: 0.7, rough: 0.45, side: THREE.FrontSide }));
  const pIn = mesh(g, pGeo, std(0xcdd5d8, { metal: 0.25, rough: 0.6, side: THREE.BackSide }));
  pIn.scale.set(1, 0.992, 0.992);

  // ---------------- frame ribs + bulkheads + deck
  const ribMat = std(0x8d989d, { metal: 0.6, rough: 0.4 });
  const ribGeo = new THREE.TorusGeometry(RP - 0.04, 0.035, 8, 64);
  ribGeo.rotateY(Math.PI / 2);
  for (let x = -13.5; x <= 13.2; x += 1.5) mesh(g, ribGeo, ribMat, x, 0, 0);
  const bulkMat = std(0xd7b24a, { metal: 0.3, rough: 0.5 });
  for (const x of [-6.4, 4.4, 13.2]) {
    const d = new THREE.CylinderGeometry(RP - 0.03, RP - 0.03, 0.12, 64);
    d.rotateZ(Math.PI / 2);
    mesh(g, d, bulkMat, x, 0, 0);
  }
  mesh(g, new THREE.BoxGeometry(26, 0.06, 3.6), std(0x35424a, { metal: 0.3, rough: 0.7 }), -0.4, -1.74, 0);

  // ---------------- control room + torpedo room (forward compartments)
  const consoleMat = std(0x46535b, { metal: 0.4, rough: 0.5 });
  const screenMat = std(0x0b2a1d, { emissive: 0x2dff9a, emissiveI: 1.4, metal: 0, rough: 0.3 });
  for (let i = 0; i < 4; i++) {
    const x = 5.6 + i * 1.1;
    mesh(g, new THREE.BoxGeometry(0.8, 0.9, 0.6), consoleMat, x, -1.25, -0.9);
    const s = mesh(g, new THREE.BoxGeometry(0.62, 0.34, 0.04), screenMat, x, -0.62, -0.62);
    s.rotation.x = -0.35;
  }
  const torpMat = std(0xb9c1c6, { metal: 0.8, rough: 0.3 });
  const noseMat = std(0xc0392b, { metal: 0.3, rough: 0.5 });
  for (let k = 0; k < 4; k++) {
    const y = -0.6 + (k % 2) * 1.0;
    const z = -0.7 - Math.floor(k / 2) * 0.62;
    mesh(g, cylX(0.22, 0.22, 3.0, 20), torpMat, 11.4, y - 0.7, z);
    const nose = new THREE.ConeGeometry(0.22, 0.5, 20);
    nose.rotateZ(-Math.PI / 2);
    mesh(g, nose, noseMat, 13.15, y - 0.7, z);
  }
  // compressed-air bank (used to blow the ballast tanks)
  const bottleMat = std(0xa93226, { metal: 0.5, rough: 0.4 });
  for (let i = 0; i < 5; i++) mesh(g, new THREE.CylinderGeometry(0.2, 0.2, 1.7, 20), bottleMat, 1.2 + i * 0.5, -0.85, -1.0);

  // ---------------- ballast tanks (between pressure hull and outer hull)
  const baffleMat = std(0x2f8aa0, { metal: 0.2, rough: 0.6 });
  const baffleGeo = new THREE.RingGeometry(RP, RM - 0.02, 64, 1);
  baffleGeo.rotateY(Math.PI / 2);
  for (const [x0, x1] of [FWD_MBT, AFT_MBT]) {
    for (let i = 0; i <= 5; i++) mesh(g, baffleGeo, baffleMat, x0 + ((x1 - x0) * i) / 5, 0, 0);
  }
  const waterMat = std(0x2aa7d8, { opacity: 0.62, emissive: 0x0a6a96, emissiveI: 0.55, metal: 0.1, rough: 0.2 });
  waterMat.clippingPlanes = [cutPlane, waterPlane];
  for (const [x0, x1] of [FWD_MBT, AFT_MBT]) {
    const shape = new THREE.Shape();
    shape.absarc(0, 0, RM - 0.12, 0, Math.PI * 2, false);
    const hole = new THREE.Path();
    hole.absarc(0, 0, RP + 0.04, 0, Math.PI * 2, true);
    shape.holes.push(hole);
    const geo = new THREE.ExtrudeGeometry(shape, { depth: x1 - x0, bevelEnabled: false, curveSegments: 48 });
    geo.rotateY(Math.PI / 2);
    geo.translate(x0, 0, 0);
    mesh(g, geo, waterMat);
  }
  // vent valves on top of the forward tank (open at 19.5 s)
  const ventPositions: P3[] = [
    [7.4, RM, -0.2],
    [9.6, RM, -0.2],
    [11.8, RM, -0.2],
  ];
  const ventMat = std(0xe3b23c, { metal: 0.6, rough: 0.35 });
  const ventLids: THREE.Mesh[] = [];
  for (const [x, y, z] of ventPositions) {
    mesh(g, new THREE.CylinderGeometry(0.16, 0.2, 0.34, 20), ventMat, x, y + 0.05, z);
    const lid = mesh(g, new THREE.CylinderGeometry(0.24, 0.24, 0.05, 20), ventMat, x, y + 0.27, z);
    ventLids.push(lid);
  }

  // ---------------- sail (fairwater), periscopes, dive planes
  const bodyMat = std(0x1e272d, { metal: 0.35, rough: 0.55, bump: tiles, bumpScale: 0.5 });
  const sailGeo = new THREE.CapsuleGeometry(0.55, 3.2, 8, 24);
  sailGeo.rotateZ(Math.PI / 2);
  sailGeo.scale(1, 2.5, 1.9);
  const sail = mesh(g, sailGeo, bodyMat, 6.2, 4.15, 0);
  sail.castShadow = true;
  mesh(g, new THREE.BoxGeometry(1.2, 0.08, 4.8), bodyMat, 6.9, 4.45, 0);
  const mastMat = std(0xaab4ba, { metal: 0.85, rough: 0.25 });
  mesh(g, new THREE.CylinderGeometry(0.07, 0.07, 7.4, 16), mastMat, 6.6, 2.9, -0.15);
  mesh(g, new THREE.CylinderGeometry(0.1, 0.1, 6.6, 16), mastMat, 5.7, 3.3, -0.15);
  mesh(g, new THREE.CylinderGeometry(0.11, 0.07, 0.35, 16), mastMat, 6.6, 6.7, -0.15);

  // ---------------- stern control surfaces
  for (let k = 0; k < 4; k++) {
    const holder = new THREE.Group();
    holder.position.set(-20.6, 0, 0);
    holder.rotation.x = (k * Math.PI) / 2;
    g.add(holder);
    mesh(holder, new THREE.BoxGeometry(1.7, 2.0, 0.09), bodyMat, 0, 2.3, 0);
  }

  // ---------------- sonar: spherical array in the free-flooded bow dome
  const sonar = new THREE.Group();
  sonar.position.set(19.3, -0.2, 0);
  g.add(sonar);
  mesh(sonar, new THREE.SphereGeometry(1.35, 48, 32), std(0x6f7c83, { metal: 0.85, rough: 0.3, clip: false }));
  const staveGeo = new THREE.CylinderGeometry(0.1, 0.12, 0.16, 12);
  const staveMat = std(0x101820, { emissive: 0x19c9ff, emissiveI: 0.8, metal: 0.2, rough: 0.4, clip: false });
  const N = 96;
  const inst = new THREE.InstancedMesh(staveGeo, staveMat, N);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < N; i++) {
    const y = 1 - (2 * (i + 0.5)) / N;
    const r = Math.sqrt(1 - y * y);
    const th = i * 2.399963;
    const n = new THREE.Vector3(Math.cos(th) * r, y, Math.sin(th) * r);
    dummy.position.copy(n).multiplyScalar(1.4);
    dummy.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), n);
    dummy.updateMatrix();
    inst.setMatrixAt(i, dummy.matrix);
  }
  sonar.add(inst);
  const strutMat = std(0x8d989d, { metal: 0.7, rough: 0.4, clip: false });
  for (const a of [0, 1, 2]) {
    const strut = mesh(sonar, new THREE.CylinderGeometry(0.06, 0.06, 3.4, 10), strutMat);
    strut.rotation.z = Math.PI / 2;
    strut.rotation.x = (a * Math.PI * 2) / 3;
    strut.position.set(-2.4, 0, 0);
  }

  const update = (t: number, subY: number): void => {
    // cutaway reveal sweeps the clip plane through the hull
    const reveal = smoother(ramp(t, C.cutawayStart, C.cutawayEnd));
    cutPlane.constant = 4.0 - 4.0 * reveal;
    // ballast tanks flood from the bottom up while the vents are open
    const fill = smooth(ramp(t, C.ballastFloodStart, C.ballastFloodEnd));
    waterPlane.constant = subY + (-3.6 + 7.2 * fill);
    const open = smooth(ramp(t, C.ventOpen, C.ventOpen + 0.3));
    ventLids.forEach((lid, i) => {
      lid.position.y = ventPositions[i][1] + 0.27 + 0.22 * open;
      lid.rotation.z = 0.5 * open * (i % 2 === 0 ? 1 : -1);
    });
    // sonar staves flash on each ping
    let flash = 0.35;
    for (const tp of C.sonarPings) flash += 1.6 * Math.exp(-Math.pow((t - tp - 0.05) / 0.18, 2)) * (t >= tp ? 1 : 0);
    staveMat.emissiveIntensity = flash;
    sonar.rotation.x = t * 0.5;
  };
  return { group: g, update, ventLids, ventPositions };
};
