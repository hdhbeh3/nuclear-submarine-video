import * as THREE from "three";
import { C, coreGlow, ramp, smooth } from "../timing";
import { mesh, cylX, tube, makeAngle, softDot, P3 } from "./util";
import { std } from "./materials";

/** Drivetrain speeds (rad/s). Turbine speeds are limited so 12-blade rows never alias at 30 fps. */
const shaftOmega = (t: number): number => 1.4 + 2.2 * smooth(ramp(t, C.turbineStart, 18.5)) - 1.3 * smooth(ramp(t, 20.5, 24)) + 0.9 * smooth(ramp(t, C.nuclearPower, C.finalHit));
const GEAR_RATIO = 2; // pinion (12 teeth) turns twice as fast as the bull gear (24 teeth)

export type Flow = { curve: THREE.CatmullRomCurve3; pts: THREE.Points; n: number; speed: number; start: number; jitter: number };

export type MachineryRig = {
  group: THREE.Group;
  update: (t: number) => void;
  propellerGroup: THREE.Group;
  coreWorld: THREE.Vector3;
};

const gearBuild = (parent: THREE.Object3D, r: number, teeth: number, x: number, y: number, mat: THREE.Material, hubMat: THREE.Material): THREE.Group => {
  const grp = new THREE.Group();
  grp.position.set(x, y, 0);
  parent.add(grp);
  mesh(grp, cylX(r - 0.05, r - 0.05, 0.3, 48), mat);
  mesh(grp, cylX(r * 0.28, r * 0.28, 0.5, 24), hubMat);
  const toothGeo = new THREE.BoxGeometry(0.3, 0.12, (Math.PI * 2 * r) / teeth * 0.5);
  const inst = new THREE.InstancedMesh(toothGeo, mat, teeth);
  const d = new THREE.Object3D();
  for (let i = 0; i < teeth; i++) {
    const a = (i / teeth) * Math.PI * 2;
    d.position.set(0, Math.cos(a) * (r + 0.02), Math.sin(a) * (r + 0.02));
    d.rotation.set(a, 0, 0);
    d.updateMatrix();
    inst.setMatrixAt(i, d.matrix);
  }
  inst.instanceMatrix.needsUpdate = true;
  grp.add(inst);
  return grp;
};

const rotorBuild = (parent: THREE.Object3D, x0: number, x1: number, rA: number, rB: number, rows: number, steel: THREE.Material, bronze: THREE.Material): THREE.Group => {
  // x0 > x1 : steam enters at x0 (+x side, small radius) and expands toward x1
  const rot = new THREE.Group();
  parent.add(rot);
  mesh(rot, cylX(0.13, 0.13, x0 - x1 + 0.6, 16), steel, (x0 + x1) / 2, 0, 0);
  const B = 12;
  const inst = new THREE.InstancedMesh(new THREE.BoxGeometry(0.07, 1, 0.22), bronze, rows * B);
  const d = new THREE.Object3D();
  for (let r = 0; r < rows; r++) {
    const k = rows === 1 ? 0 : r / (rows - 1);
    const x = x0 + (x1 - x0) * k;
    const radius = rA + (rB - rA) * k;
    mesh(rot, cylX(radius * 0.55, radius * 0.55, 0.06, 28), steel, x, 0, 0);
    const bl = radius * 0.45;
    for (let b = 0; b < B; b++) {
      const a = (b / B) * Math.PI * 2 + r * 0.31;
      const rr = radius * 0.55 + bl / 2;
      d.position.set(x, Math.cos(a) * rr, Math.sin(a) * rr);
      d.rotation.set(a, 0.3, 0);
      d.scale.set(1, bl, 1);
      d.updateMatrix();
      inst.setMatrixAt(r * B + b, d.matrix);
    }
  }
  inst.instanceMatrix.needsUpdate = true;
  rot.add(inst);
  return rot;
};

export const buildMachinery = (): MachineryRig => {
  const g = new THREE.Group();
  const steel = std(0xaeb7bd, { metal: 0.75, rough: 0.33 });
  const darkSteel = std(0x5c676e, { metal: 0.8, rough: 0.4 });
  const bronze = std(0xc9a24d, { metal: 0.9, rough: 0.3 });
  const yellow = std(0xe0b030, { metal: 0.4, rough: 0.45 });
  const orange = std(0xe2681b, { metal: 0.4, rough: 0.45 });
  const hotPipe = std(0xd9531e, { emissive: 0xff4a10, emissiveI: 0.25, metal: 0.6, rough: 0.35 });
  const coldPipe = std(0x9a3a1c, { emissive: 0xaa2a08, emissiveI: 0.1, metal: 0.6, rough: 0.4 });
  const steamPipe = std(0xe9edf0, { metal: 0.6, rough: 0.35 });
  const waterPipe = std(0x2f86c7, { metal: 0.6, rough: 0.35 });

  // ================= nuclear reactor vessel (x = -0.5) =================
  const rx = -0.5;
  const ry = -0.4;
  const reactor = new THREE.Group();
  reactor.position.set(rx, ry, 0);
  g.add(reactor);
  mesh(reactor, new THREE.CylinderGeometry(0.75, 0.75, 2.2, 40, 1, true), steel);
  const dome = new THREE.SphereGeometry(0.75, 40, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  mesh(reactor, dome, steel, 0, 1.1, 0);
  const domeB = new THREE.SphereGeometry(0.75, 40, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2);
  mesh(reactor, domeB, steel, 0, -1.1, 0);
  for (const y of [-0.62, 0.62]) mesh(reactor, new THREE.TorusGeometry(0.77, 0.05, 10, 48).rotateX(Math.PI / 2), orange, 0, y, 0);
  // radiation shield ring (shows the vessel is shielded)
  mesh(reactor, new THREE.TorusGeometry(0.98, 0.09, 12, 48).rotateX(Math.PI / 2), yellow, 0, 0.0, 0);
  // fuel rods = glowing core
  const rodMat = std(0xffb24a, { emissive: 0xff7a18, emissiveI: 1, metal: 0.2, rough: 0.4, clip: true });
  const rods: THREE.Mesh[] = [];
  for (let i = -1; i <= 1; i++) {
    for (let j = -1; j <= 1; j++) {
      rods.push(mesh(reactor, new THREE.CylinderGeometry(0.06, 0.06, 1.35, 12), rodMat, i * 0.22, -0.1, j * 0.22));
    }
  }
  const glowMat = new THREE.MeshBasicMaterial({ color: 0xff8a2a, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  mesh(reactor, new THREE.CylinderGeometry(0.52, 0.52, 1.45, 32, 1, true), glowMat, 0, -0.1, 0);
  // control rods (move up/down)
  const ctrlMat = std(0x30363a, { metal: 0.8, rough: 0.35 });
  const ctrl: THREE.Mesh[] = [];
  for (const [i, j] of [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3]] as const) {
    ctrl.push(mesh(reactor, new THREE.CylinderGeometry(0.045, 0.045, 1.9, 10), ctrlMat, i, 1.05, j));
  }
  // glow halo sprite (fake bloom)
  const haloMat = new THREE.SpriteMaterial({ map: softDot(0), color: 0xff8a2a, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const halo = new THREE.Sprite(haloMat);
  halo.scale.set(3.2, 3.2, 1);
  halo.position.set(0, -0.1, 0.1);
  reactor.add(halo);
  const reactorLight = new THREE.PointLight(0xff8a2a, 14, 7, 2);
  reactorLight.position.set(0, -0.1, 0.6);
  reactor.add(reactorLight);

  // ================= primary loop: reactor -> steam generator -> pump -> reactor =================
  const hot = tube([[-1.2, 0.35, 0], [-2.2, 0.35, 0], [-3.7, 0.35, 0]], 0.17, hotPipe, g);
  const cold1 = tube([[-3.7, -1.1, 0], [-3.0, -1.1, 0], [-2.7, -1.1, 0]], 0.17, coldPipe, g);
  const cold2 = tube([[-2.1, -1.1, 0], [-1.7, -1.1, 0], [-1.2, -1.1, 0]], 0.17, coldPipe, g);
  void cold1;
  void cold2;
  const pumpGeo = cylX(0.4, 0.4, 0.7, 28);
  mesh(g, pumpGeo, darkSteel, -2.4, -1.1, 0);
  mesh(g, new THREE.SphereGeometry(0.42, 24, 16), steel, -2.4, -1.1, 0);
  mesh(g, new THREE.BoxGeometry(0.5, 0.4, 0.5), std(0x2a6db5, { metal: 0.4, rough: 0.5 }), -2.4, -0.72, 0);

  // ================= steam generator (x = -4.4) =================
  const sg = new THREE.Group();
  sg.position.set(-4.4, 0, 0);
  g.add(sg);
  mesh(sg, new THREE.CylinderGeometry(0.7, 0.7, 2.8, 36, 1, true), std(0xc9ced2, { metal: 0.6, rough: 0.4 }));
  mesh(sg, new THREE.SphereGeometry(0.7, 36, 16, 0, Math.PI * 2, 0, Math.PI / 2), steel, 0, 1.4, 0);
  mesh(sg, new THREE.SphereGeometry(0.7, 36, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), steel, 0, -1.4, 0);
  mesh(sg, new THREE.TorusGeometry(0.72, 0.05, 10, 40).rotateX(Math.PI / 2), yellow, 0, 0.9, 0);
  mesh(sg, new THREE.TorusGeometry(0.72, 0.05, 10, 40).rotateX(Math.PI / 2), yellow, 0, -0.9, 0);
  const bundleMat = std(0xe0682a, { emissive: 0xff4a10, emissiveI: 0.35, metal: 0.5, rough: 0.4 });
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const rad = 0.18 + 0.28 * ((i % 3) / 2);
    mesh(sg, new THREE.CylinderGeometry(0.035, 0.035, 2.3, 8), bundleMat, Math.cos(a) * rad, 0, Math.sin(a) * rad);
  }

  // ================= secondary loop: steam line -> turbines -> condenser -> feed water =================
  const steamLine = tube([[-4.4, 1.75, -0.4], [-4.7, 1.9, -0.4], [-6.4, 1.92, -0.4], [-8.0, 1.9, -0.4], [-8.4, 1.75, -0.3]], 0.14, steamPipe, g);
  const steamPath = new THREE.CatmullRomCurve3(
    [[-4.4, 1.6, -0.4], [-4.7, 1.9, -0.4], [-6.4, 1.92, -0.4], [-8.0, 1.9, -0.4], [-8.4, 1.6, -0.2], [-8.4, 1.25, 0], [-9.6, 1.2, 0], [-11.5, 1.2, 0], [-13.3, 1.2, 0]].map((p) => new THREE.Vector3(p[0], p[1], p[2])),
    false,
    "centripetal",
  );
  void steamLine;
  const exhaustPath = tube([[-13.45, 1.0, 0], [-13.3, 0.2, 0], [-12.6, -0.5, 0]], 0.2, steamPipe, g);
  const feed = tube([[-8.6, -1.15, 0], [-7.6, -1.5, 0], [-5.6, -1.78, 0], [-4.4, -1.78, 0], [-4.4, -1.5, 0]], 0.1, waterPipe, g);

  // turbines: HP (x -9.4 .. -7.4), LP (x -13.2 .. -9.9), axis y = 1.2
  const AX = 1.2;
  const turbine = new THREE.Group();
  turbine.position.set(0, AX, 0);
  g.add(turbine);
  const hpCasing = std(0xb4bcc1, { metal: 0.7, rough: 0.35 });
  mesh(turbine, cylX(0.72, 0.5, 2.0, 40, true), hpCasing, -8.4, 0, 0);
  mesh(turbine, cylX(1.0, 0.7, 3.3, 40, true), hpCasing, -11.55, 0, 0);
  mesh(turbine, cylX(0.5, 0.5, 0.5, 24, true), darkSteel, -9.65, 0, 0); // crossover
  for (const x of [-7.4, -9.4, -9.9, -13.2]) mesh(turbine, new THREE.TorusGeometry(x === -13.2 || x === -9.9 ? 1.0 : x === -9.4 ? 0.72 : 0.5, 0.05, 8, 40).rotateY(Math.PI / 2), yellow, x, 0, 0);
  const turbRot = new THREE.Group();
  turbine.add(turbRot);
  const hpRotor = rotorBuild(turbRot, -7.5, -9.3, 0.5, 0.68, 5, steel, bronze);
  const lpRotor = rotorBuild(turbRot, -9.95, -13.1, 0.7, 0.98, 6, steel, bronze);
  void hpRotor;
  void lpRotor;
  mesh(turbRot, cylX(0.12, 0.12, 7.1, 16), steel, -10.7, 0, 0);

  // condenser under the turbines
  mesh(g, cylX(0.55, 0.55, 4.0, 32, true), std(0x7fa7c4, { metal: 0.6, rough: 0.4 }), -10.6, -1.15, 0);
  for (const x of [-12.6, -8.6]) mesh(g, new THREE.CylinderGeometry(0.55, 0.55, 0.05, 32).rotateZ(Math.PI / 2), darkSteel, x, -1.15, 0);

  // ================= reduction gear (pinion 12 teeth + bull gear 24 teeth) =================
  const gearMat = std(0xd2a53c, { metal: 0.9, rough: 0.3 });
  const pinion = gearBuild(g, 0.4, 12, -14.2, AX, gearMat, steel);
  const bull = gearBuild(g, 0.8, 24, -14.2, 0.0, gearMat, steel);
  mesh(g, new THREE.BoxGeometry(1.7, 3.0, 2.2), std(0x6a7a84, { opacity: 0.18, metal: 0.2, rough: 0.2 }), -14.2, 0.6, 0);
  mesh(g, cylX(0.12, 0.12, 0.9, 16), steel, -13.9, AX, 0); // turbine shaft stub into pinion

  // ================= main shaft + bearings + propeller =================
  const shaft = new THREE.Group();
  g.add(shaft);
  mesh(shaft, cylX(0.17, 0.17, 10.8, 24), std(0xcfd6da, { metal: 0.9, rough: 0.2 }), -19.6, 0, 0);
  mesh(shaft, new THREE.BoxGeometry(10.4, 0.06, 0.1), yellow, -19.6, 0.17, 0); // keyway marker shows rotation
  const brg = std(0x5c676e, { metal: 0.7, rough: 0.45 });
  for (const x of [-16.5, -19.5, -22.2]) mesh(g, new THREE.BoxGeometry(0.5, 0.55, 0.55), brg, x, 0, 0);

  const prop = new THREE.Group();
  prop.position.set(-24.9, 0, 0);
  g.add(prop);
  const bladeMat = std(0xb98a4a, { metal: 0.95, rough: 0.28, env: 1.1, clip: false });
  mesh(prop, cylX(0.5, 0.42, 0.8, 24), bladeMat, 0.1, 0, 0);
  const tail = new THREE.ConeGeometry(0.42, 1.2, 24);
  tail.rotateZ(Math.PI / 2);
  mesh(prop, tail, bladeMat, -0.9, 0, 0);
  for (let k = 0; k < 7; k++) {
    const arm = new THREE.Group();
    arm.rotation.x = (k * Math.PI * 2) / 7;
    prop.add(arm);
    const bl = new THREE.SphereGeometry(1, 20, 14);
    bl.scale(0.09, 1.25, 0.46);
    const m = mesh(arm, bl, bladeMat, 0, 1.45, 0);
    m.rotation.y = 0.55;
    m.rotation.z = 0.2;
  }

  // ================= flowing particles (hot water, steam, condensate) =================
  const makeFlow = (curve: THREE.CatmullRomCurve3, n: number, color: number, size: number, speed: number, start: number, jitter: number): Flow => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    const mat = new THREE.PointsMaterial({ color, size, map: softDot(0), transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
    const pts = new THREE.Points(geo, mat);
    pts.frustumCulled = false;
    g.add(pts);
    return { curve, pts, n, speed, start, jitter };
  };
  const primaryCurve = new THREE.CatmullRomCurve3([[-1.2, 0.35, 0.02], [-3.7, 0.35, 0.02], [-4.2, -0.4, 0.02], [-3.7, -1.1, 0.02], [-1.2, -1.1, 0.02]].map((p) => new THREE.Vector3(p[0], p[1], p[2])));
  const flows: Flow[] = [
    makeFlow(primaryCurve, 46, 0xff7a2a, 0.2, 0.16, 5.6, 0.04),
    makeFlow(steamPath, 90, 0xf4f8ff, 0.24, 0.12, C.steamStart, 0.06),
    makeFlow(exhaustPath, 24, 0xcfe6ff, 0.2, 0.2, C.turbineStart, 0.05),
    makeFlow(feed, 26, 0x62b8ff, 0.16, 0.14, C.steamStart, 0.02),
  ];
  const tmp = new THREE.Vector3();

  const angShaft = makeAngle(shaftOmega);
  const coreWorld = new THREE.Vector3(rx, ry, 0);

  const update = (t: number): void => {
    // ---- reactor
    const glow = coreGlow(t);
    rodMat.emissiveIntensity = 0.5 + 1.4 * glow;
    glowMat.opacity = 0.12 + 0.28 * glow;
    haloMat.opacity = Math.min(1, 0.18 + 0.4 * glow);
    halo.scale.setScalar(2.4 + 1.1 * glow);
    reactorLight.intensity = 6 + 14 * glow;
    ctrl.forEach((c, i) => (c.position.y = 1.05 + 0.14 * Math.sin(t * 1.4 + i * 1.7)));
    rods.forEach((r, i) => (r.scale.y = 1 + 0.01 * Math.sin(t * 6 + i)));
    // ---- primary loop heats up as the reactor ramps
    hotPipe.emissiveIntensity = 0.15 + 0.9 * smooth(ramp(t, 6.0, 10.5)) * (0.8 + 0.2 * Math.sin(t * 3));
    bundleMat.emissiveIntensity = 0.2 + 1.0 * smooth(ramp(t, 6.5, 12.0));
    // ---- drivetrain
    const th = angShaft(t);
    shaft.rotation.x = th;
    prop.rotation.x = th;
    bull.rotation.x = th;
    pinion.rotation.x = -th * GEAR_RATIO + Math.PI / 12; // meshes with the bull gear (opposite sense, half-tooth phase)
    turbRot.rotation.x = -th * GEAR_RATIO;
    // ---- particles
    for (const f of flows) {
      const mat = f.pts.material as THREE.PointsMaterial;
      const on = smooth(ramp(t, f.start, f.start + 0.5));
      mat.opacity = on * 0.85;
      const arr = (f.pts.geometry.getAttribute("position") as THREE.BufferAttribute).array as Float32Array;
      const speedUp = 1 + 1.4 * smooth(ramp(t, C.turbineStart, 17));
      for (let i = 0; i < f.n; i++) {
        const u = (((i / f.n + (t - f.start) * f.speed * speedUp) % 1) + 1) % 1;
        f.curve.getPointAt(u, tmp);
        const jx = Math.sin(i * 12.9 + t * 3) * f.jitter;
        const jy = Math.cos(i * 7.7 + t * 2.3) * f.jitter;
        arr[i * 3] = tmp.x + jx;
        arr[i * 3 + 1] = tmp.y + jy;
        arr[i * 3 + 2] = tmp.z + Math.sin(i * 3.1 + t) * f.jitter;
      }
      (f.pts.geometry.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
    }
    void feed;
    void hot;
  };

  return { group: g, update, propellerGroup: prop, coreWorld };
};
