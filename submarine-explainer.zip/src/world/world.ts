import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { C, lightLevel, ramp, smooth, lerp } from "../timing";
import { cameraAt, subPose } from "../camera";
import { buildHull } from "./hull";
import { buildMachinery } from "./machinery";
import { buildEnvironment, buildBubbles, DRIFT } from "./environment";

export type World = {
  root: THREE.Group;
  attach: (scene: THREE.Scene, gl: THREE.WebGLRenderer) => void;
  update: (t: number, scene: THREE.Scene, camera: THREE.PerspectiveCamera) => void;
};

const BRIGHT = new THREE.Color(0x0d5a80);
const DARK = new THREE.Color(0x01070c);

export const createWorld = (): World => {
  const root = new THREE.Group();

  // ---------------- submarine
  const sub = new THREE.Group();
  root.add(sub);
  const hull = buildHull();
  sub.add(hull.group);
  const machinery = buildMachinery();
  sub.add(machinery.group);
  sub.traverse((o: THREE.Object3D) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) m.castShadow = true;
  });

  // interior lights (warm work lights) travel with the sub
  const warm: THREE.PointLight[] = [];
  for (const x of [-12, -7, -2.5, 2, 6.5, 10.5]) {
    const l = new THREE.PointLight(0xffc88a, 22, 9, 2);
    l.position.set(x, 1.45, 1.3);
    sub.add(l);
    warm.push(l);
  }

  // ---------------- bubbles: propeller wake, vent blow-off, drive-by
  const wake = buildBubbles({ origin: [-26, 0, 0], vel: [-4.5, 0.25, 0], spread: [0.6, 2.4, 2.4], count: 220, life: [3, 5], size: 0.2, color: 0xcfeeff, opacity: 0.75 });
  sub.add(wake.points);
  const vents = hull.ventPositions.map((p) =>
    buildBubbles({ origin: [p[0], p[1] + 0.5, p[2]], vel: [0.1, 2.2, 0], spread: [0.5, 0.2, 0.5], count: 70, life: [1.4, 2.4], size: 0.26, color: 0xe6f6ff, opacity: 0.9 }),
  );
  vents.forEach((v) => sub.add(v.points));

  // ---------------- environment
  const env = buildEnvironment();
  root.add(env.group);

  // ---------------- lights
  const sun = new THREE.DirectionalLight(0x9fdcff, 2.0);
  sun.position.set(-12, 44, 16);
  sun.target.position.set(0, 0, 0);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -36;
  sun.shadow.camera.right = 36;
  sun.shadow.camera.top = 36;
  sun.shadow.camera.bottom = -36;
  sun.shadow.camera.near = 5;
  sun.shadow.camera.far = 120;
  sun.shadow.bias = -0.0006;
  root.add(sun, sun.target);
  const fill = new THREE.DirectionalLight(0xbcd8e6, 0.9); // cinematic key from the lens side
  fill.position.set(-6, 10, 60);
  root.add(fill);
  const hemi = new THREE.HemisphereLight(0x3b9cc4, 0x06161d, 0.5);
  root.add(hemi);

  const attach = (scene: THREE.Scene, gl: THREE.WebGLRenderer): void => {
    gl.localClippingEnabled = true;
    gl.shadowMap.enabled = true;
    gl.shadowMap.type = THREE.PCFSoftShadowMap;
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.05;
    const pm = new THREE.PMREMGenerator(gl);
    scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.fog = new THREE.FogExp2(0x0d5a80, 0.016);
    scene.background = new THREE.Color(0x0d5a80);
  };

  const tmpColor = new THREE.Color();

  const update = (t: number, scene: THREE.Scene, camera: THREE.PerspectiveCamera): void => {
    const pose = subPose(t);
    sub.position.set(0, pose.y, 0);
    sub.rotation.z = pose.pitch;

    hull.update(t, pose.y);
    machinery.update(t);
    env.update(t, pose.y);

    // bubbles
    wake.update(t, 1);
    const ventOn = smooth(ramp(t, C.ventOpen, C.ventOpen + 0.25)) * (1 - smooth(ramp(t, C.ballastFloodEnd, C.ballastFloodEnd + 0.6)));
    vents.forEach((v) => v.update(t, ventOn));

    // ---- ocean light follows the narration (sunlit -> dark depths)
    const L = lightLevel(t);
    sun.intensity = 2.0 * L + 0.02;
    hemi.intensity = 0.5 * L + 0.07;
    fill.intensity = 0.25 + 0.65 * Math.sqrt(L);
    tmpColor.copy(DARK).lerp(BRIGHT, Math.pow(L, 1.3));
    (scene.fog as THREE.FogExp2).color.copy(tmpColor);
    (scene.fog as THREE.FogExp2).density = lerp(0.016, 0.0105, 1 - L);
    (scene.background as THREE.Color).copy(tmpColor);
    warm.forEach((l, i) => (l.intensity = 20 + 3 * Math.sin(t * 2 + i)));

    // ---- sonar ping rings (translucent expanding wavefronts)
    pingUpdate(t, pose.y);

    // ---- camera
    const cam = cameraAt(t);
    camera.position.set(cam.pos[0], cam.pos[1], cam.pos[2]);
    camera.fov = cam.fov;
    camera.near = 0.3;
    camera.far = 500;
    camera.lookAt(cam.look[0], cam.look[1], cam.look[2]);
    camera.updateProjectionMatrix();
  };

  // ---------------- sonar rings
  const ringMat = new THREE.MeshBasicMaterial({ color: 0x7fe9ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  const ringGeo = new THREE.RingGeometry(0.965, 1, 128, 1);
  const rings: THREE.Mesh[] = [];
  const mats: THREE.MeshBasicMaterial[] = [];
  for (let i = 0; i < C.sonarPings.length * 2; i++) {
    const m = new THREE.MeshBasicMaterial({ color: 0x7fe9ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const r = new THREE.Mesh(ringGeo, m);
    r.visible = false;
    root.add(r);
    rings.push(r);
    mats.push(m);
  }
  void ringMat;
  const pingUpdate = (t: number, subY: number): void => {
    C.sonarPings.forEach((tp, k) => {
      for (let j = 0; j < 2; j++) {
        const idx = k * 2 + j;
        const age = t - tp - j * 0.16;
        const r = rings[idx];
        if (age < 0 || age > 3.2) {
          r.visible = false;
          continue;
        }
        r.visible = true;
        const R = 1.6 + 28 * age;
        r.scale.setScalar(R);
        r.position.set(19.3, subY - 0.2, 0);
        mats[idx].opacity = (j === 0 ? 0.85 : 0.45) * Math.pow(Math.max(0, 1 - age / 3.2), 1.6);
      }
    });
  };
  void DRIFT;

  return { root, attach, update };
};
