import { C, clamp, ramp, smoother } from "./timing";

export type V3 = [number, number, number];
type Key = { t: number; p: V3; l: V3; f: number };

/**
 * Camera keyframes in SUBMARINE space (x = along hull, bow = +x, y up, +z toward the viewer).
 * Times are seconds on the voiceover timeline. Sub-space y is offset by the sub's dive depth at render time.
 *   S1 0.2-4.9    exterior hero, bow -> sail
 *   S2 5.0-10.97  cutaway reveal -> reactor macro
 *   S3 11.0-19.15 steam generator -> turbines (13.5) -> reduction gear/shaft (17.2) -> propeller
 *   S4 19.2-22.9  whip to the forward ballast tanks, flooding + dive
 *   S5 23.0-28.6  sonar sphere macro (pings at 23.1/24.5/25.9/27.3), then forward look into the dark
 *   S6 28.7-33.7  dark, reactor glow, final hero pull-back from behind the stern
 */
const K: Key[] = [
  { t: 0.0, p: [41, -2.2, 9], l: [16, 0.6, 0], f: 58 },
  { t: 2.5, p: [33, 2.5, 21], l: [10, 1.2, 0], f: 54 },
  { t: 4.9, p: [13, 4.0, 27], l: [3, 1.2, 0], f: 50 },
  { t: 7.0, p: [4, 0.8, 17], l: [-1.5, 0, 0], f: 48 },
  { t: 9.0, p: [0.8, 0.2, 12], l: [-0.8, -0.2, 0], f: 46 },
  { t: 10.9, p: [-0.6, -0.2, 8.6], l: [-0.5, -0.3, 0], f: 44 },
  { t: 12.4, p: [-4.2, 0.3, 9.5], l: [-4.4, 0.2, 0], f: 46 },
  { t: 13.5, p: [-6.8, 0.9, 9], l: [-7.4, 1.0, 0], f: 46 },
  { t: 15.3, p: [-9.8, 1.1, 7.5], l: [-10.2, 1.1, 0], f: 44 },
  { t: 17.1, p: [-12.8, 0.9, 8], l: [-13.4, 0.8, 0], f: 46 },
  { t: 17.9, p: [-20.5, 1.6, 5.8], l: [-14.6, 0.2, 0], f: 48 },
  { t: 18.6, p: [-33, 2.5, 12], l: [-24.2, 0, 0], f: 52 },
  { t: 19.2, p: [-35, 1.5, 14], l: [-24.5, 0, 0], f: 52 },
  { t: 20.6, p: [10.5, 0.8, 13.5], l: [10.2, 0.4, 0], f: 50 },
  { t: 22.9, p: [15, -1.5, 25], l: [7, -2.5, 0], f: 50 },
  { t: 23.8, p: [30, 0.6, 12], l: [19.5, -0.2, 0], f: 48 },
  { t: 25.3, p: [27, 1.5, 9.5], l: [19.6, -0.2, 0], f: 44 },
  { t: 26.4, p: [18, 0.5, 20], l: [26, -1, -2], f: 52 },
  { t: 27.5, p: [4, 0.8, 20], l: [34, -2.5, -6], f: 56 },
  { t: 28.6, p: [-6, 1.5, 22], l: [40, -3, -8], f: 58 },
  { t: 29.6, p: [-10, 0, 30], l: [8, -0.5, 0], f: 54 },
  { t: 30.8, p: [0, -0.8, 19], l: [-0.5, -0.4, 0], f: 50 },
  { t: 32.0, p: [-24, 0.8, 22], l: [-4, -0.5, 0], f: 50 },
  { t: 33.2, p: [-42, 3.2, 25], l: [0, -0.3, 0], f: 48 },
  { t: 33.95, p: [-45, 4.0, 26.5], l: [1, -0.3, 0], f: 48 },
];

/** Submarine dive pose (sinks while the ballast tanks flood, 19.8-22.4 s). */
export const subPose = (t: number): { y: number; pitch: number } => {
  const bob = 0.07 * Math.sin(t * 1.1);
  const y = -4.6 * smoother(ramp(t, C.diveStart, C.diveEnd)) - 0.25 * ramp(t, C.diveEnd, 33.9) + bob;
  const pitch = -0.08 * Math.sin(Math.PI * ramp(t, C.diveStart, 24.4)) + 0.004 * Math.sin(t * 0.8);
  return { y, pitch };
};

const hermite = (p0: number, p1: number, m0: number, m1: number, u: number): number => {
  const u2 = u * u;
  const u3 = u2 * u;
  return (2 * u3 - 3 * u2 + 1) * p0 + (u3 - 2 * u2 + u) * m0 + (-2 * u3 + 3 * u2) * p1 + (u3 - u2) * m1;
};

const sample = (t: number, get: (k: Key) => number): number => {
  const tt = clamp(t, K[0].t, K[K.length - 1].t);
  let i = 0;
  while (i < K.length - 2 && tt > K[i + 1].t) i++;
  const a = K[i];
  const b = K[i + 1];
  const dt = b.t - a.t;
  const prev = K[Math.max(0, i - 1)];
  const next = K[Math.min(K.length - 1, i + 2)];
  const m0 = ((get(b) - get(prev)) / Math.max(1e-3, b.t - prev.t)) * dt;
  const m1 = ((get(next) - get(a)) / Math.max(1e-3, next.t - a.t)) * dt;
  // first/last segments start and end at rest
  const f0 = i === 0 ? 0 : 1;
  const f1 = i === K.length - 2 ? 0 : 1;
  return hermite(get(a), get(b), m0 * f0, m1 * f1, (tt - a.t) / dt);
};

export type CameraPose = { pos: V3; look: V3; fov: number };

/** Camera pose in WORLD space for time t (seconds). Follows the sub's dive; adds subtle handheld drift. */
export const cameraAt = (t: number): CameraPose => {
  const sy = subPose(t).y;
  const dx = 0.05 * Math.sin(t * 0.9) + 0.025 * Math.sin(t * 2.3 + 1);
  const dy = 0.04 * Math.sin(t * 1.3 + 1) + 0.02 * Math.sin(t * 2.9);
  const pos: V3 = [sample(t, (k) => k.p[0]) + dx, sample(t, (k) => k.p[1]) + sy + dy, sample(t, (k) => k.p[2])];
  const look: V3 = [sample(t, (k) => k.l[0]), sample(t, (k) => k.l[1]) + sy, sample(t, (k) => k.l[2])];
  return { pos, look, fov: sample(t, (k) => k.f) };
};
