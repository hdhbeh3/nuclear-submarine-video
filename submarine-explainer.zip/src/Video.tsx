import React from "react";
import { AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Scene3D } from "./Scene3D";
import { Overlay } from "./Overlay";

/**
 * Audio layers (all share the video timeline, nothing is re-timed):
 *  voiceover.m4a  - YOUR supplied narration, untouched (only -2.5 dB headroom gain)
 *  music.wav      - original score, sidechain-ducked under the narration by scripts/generate_audio.py
 *  sfx.wav        - original sound effects placed on the exact animation cues
 * VOICE_GAIN must equal VOICE_GAIN in scripts/generate_audio.py (that is what the mix was balanced against).
 */
const VOICE_GAIN = 0.75;

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const fadeOut = interpolate(frame, [durationInFrames - 8, durationInFrames - 1], [1, 0], { extrapolateLeft: "clamp" });
  return (
    <AbsoluteFill style={{ backgroundColor: "#01070c" }}>
      <Scene3D />
      <Overlay />
      <AbsoluteFill style={{ backgroundColor: "#000", opacity: 1 - fadeOut }} />
      <Audio src={staticFile("audio/voiceover.m4a")} volume={VOICE_GAIN} />
      <Audio src={staticFile("audio/music.wav")} volume={1} />
      <Audio src={staticFile("audio/sfx.wav")} volume={1} />
    </AbsoluteFill>
  );
};
