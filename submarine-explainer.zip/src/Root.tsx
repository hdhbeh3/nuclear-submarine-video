import React from "react";
import { Composition } from "remotion";
import { Video } from "./Video";
import { DURATION_FRAMES, FPS } from "./timing";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Submarine"
    component={Video}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
