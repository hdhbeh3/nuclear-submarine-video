import React, { useLayoutEffect, useMemo } from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { createWorld } from "./world/world";

/** Drives the 3D world from the Remotion frame number (deterministic: same frame -> same image). */
const Rig: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { gl, scene, camera, invalidate } = useThree();
  const world = useMemo(() => createWorld(), []);

  useLayoutEffect(() => {
    world.attach(scene, gl);
  }, [world, scene, gl]);

  useLayoutEffect(() => {
    const t = frame / fps;
    world.update(t, scene, camera as THREE.PerspectiveCamera);
    // render synchronously so the frame is on the canvas before Remotion captures it
    gl.render(scene, camera);
    invalidate();
  }, [frame, fps, world, scene, camera, gl, invalidate]);

  return <primitive object={world.root} />;
};

export const Scene3D: React.FC = () => {
  const { width, height } = useVideoConfig();
  return (
    <ThreeCanvas
      width={width}
      height={height}
      camera={{ fov: 50, near: 0.3, far: 500, position: [30, 0, 20] }}
      gl={{ antialias: true, preserveDrawingBuffer: true }}
      style={{ width, height }}
    >
      <Rig />
    </ThreeCanvas>
  );
};
