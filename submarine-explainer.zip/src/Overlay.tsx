import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import * as THREE from "three";
import { cameraAt, subPose } from "./camera";
import { clamp } from "./timing";

/**
 * Small component-name tags (NOT subtitles) that stay pinned to the real 3D part and clamp
 * inside the YouTube Shorts safe zone (top ~220 px, right ~140 px, bottom ~420 px kept clear).
 */
type Label = { t0: number; t1: number; text: string; sub: string; anchor: [number, number, number] };

const LABELS: Label[] = [
  { t0: 5.7, t1: 10.8, text: "NUCLEAR REACTOR", sub: "fuel core · heat source", anchor: [-0.5, 0.9, 0] },
  { t0: 11.3, t1: 13.3, text: "STEAM GENERATOR", sub: "heat → high-pressure steam", anchor: [-4.4, 1.5, 0] },
  { t0: 13.7, t1: 17.0, text: "STEAM TURBINES", sub: "steam spins the rotors", anchor: [-11.5, 2.3, 0] },
  { t0: 17.3, t1: 18.2, text: "REDUCTION GEAR", sub: "turbine → propeller shaft", anchor: [-14.2, 1.2, 0] },
  { t0: 19.5, t1: 22.8, text: "BALLAST TANKS", sub: "flood to sink · blow to rise", anchor: [10, 3.0, 0] },
  { t0: 23.3, t1: 28.4, text: "SONAR ARRAY", sub: "sound pulses map the dark", anchor: [19.3, 1.4, 0] },
];

const cam = new THREE.PerspectiveCamera(50, 1080 / 1920, 0.3, 500);

export const Overlay: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const pose = cameraAt(t);
  cam.fov = pose.fov;
  cam.aspect = width / height;
  cam.position.set(pose.pos[0], pose.pos[1], pose.pos[2]);
  cam.lookAt(pose.look[0], pose.look[1], pose.look[2]);
  cam.updateProjectionMatrix();
  cam.updateMatrixWorld(true);
  const sp = subPose(t);

  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
      {LABELS.map((l) => {
        const fade = clamp((t - l.t0) / 0.3) * clamp((l.t1 - t) / 0.3);
        if (fade <= 0) return null;
        // anchor in world space (sub pitch + dive offset)
        const c = Math.cos(sp.pitch);
        const s = Math.sin(sp.pitch);
        const w = new THREE.Vector3(l.anchor[0] * c - l.anchor[1] * s, l.anchor[0] * s + l.anchor[1] * c + sp.y, l.anchor[2]);
        const p = w.project(cam);
        const sx = (p.x * 0.5 + 0.5) * width;
        const sy = (-p.y * 0.5 + 0.5) * height;
        const x = clamp(sx - 230, 56, width - 140 - 470);
        const y = clamp(sy - 210, 230, height - 420 - 120);
        return (
          <div key={l.text} style={{ position: "absolute", left: 0, top: 0, opacity: fade }}>
            <svg width={width} height={height} style={{ position: "absolute", left: 0, top: 0 }}>
              <line x1={x + 40} y1={y + 108} x2={sx} y2={sy} stroke="#ff9a2e" strokeWidth={3} strokeLinecap="round" />
              <circle cx={sx} cy={sy} r={9} fill="none" stroke="#ff9a2e" strokeWidth={3} />
              <circle cx={sx} cy={sy} r={3.5} fill="#ff9a2e" />
            </svg>
            <div
              style={{
                position: "absolute",
                left: x,
                top: y,
                padding: "16px 26px 16px 22px",
                background: "rgba(4,16,26,0.72)",
                borderLeft: "8px solid #ff9a2e",
                borderRadius: 10,
                fontFamily: "'Arial Black', Impact, Helvetica, sans-serif",
                color: "#fff",
                boxShadow: "0 8px 30px rgba(0,0,0,0.45)",
              }}
            >
              <div style={{ fontSize: 40, letterSpacing: 2, lineHeight: 1.05 }}>{l.text}</div>
              <div style={{ fontSize: 24, fontFamily: "Arial, Helvetica, sans-serif", color: "#9fd8ee", marginTop: 6 }}>{l.sub}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
