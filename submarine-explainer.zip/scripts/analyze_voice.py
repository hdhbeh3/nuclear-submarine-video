#!/usr/bin/env python3
"""Prints speech activity and pause positions of the supplied voiceover (timing reference only)."""
import subprocess, os, numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
raw = subprocess.run(["ffmpeg", "-v", "quiet", "-i", os.path.join(ROOT, "public/audio/voiceover.m4a"),
                      "-f", "s16le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True).stdout
a = np.frombuffer(raw, dtype=np.int16).astype(float)
w = 320  # 20 ms
e = np.array([20 * np.log10(np.sqrt(np.mean(a[i:i + w] ** 2)) + 1) for i in range(0, len(a) - w, w)])
for rel in (22, 26):
    lo = e < e.max() - rel
    out, s = [], None
    for i, v in enumerate(lo):
        if v and s is None: s = i
        if not v and s is not None:
            if (i - s) * 0.02 >= 0.14: out.append((round(s * .02, 2), round(i * .02, 2)))
            s = None
    print(f"pauses (>=140 ms, {rel} dB below peak):", out)
print(f"duration: {len(a) / 16000:.2f}s")
