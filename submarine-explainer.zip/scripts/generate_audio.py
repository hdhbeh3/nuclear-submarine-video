#!/usr/bin/env python3
"""
Generates ORIGINAL music + sound effects for the submarine explainer.

- Reads cue times from src/timeline.json (shared with the Remotion scenes)
- Uses the supplied voiceover (public/audio/voiceover.m4a) ONLY as a timing /
  sidechain reference. The voiceover itself is never altered or replaced.
- Writes public/audio/music.wav (already ducked under the voice) and
  public/audio/sfx.wav, plus reports/mix_preview.wav and reports/audio_report.json

Needs: python3, numpy, scipy, ffmpeg on PATH.   Run:  python3 scripts/generate_audio.py
"""
import json, subprocess, os, wave
import numpy as np
from scipy import signal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 44100
TL = json.load(open(os.path.join(ROOT, "src", "timeline.json")))
CUES = TL["cues"]
DUR = TL["voiceDuration"] + 0.02
N = int(DUR * SR)
T = np.arange(N) / SR
rng = np.random.default_rng(7)  # deterministic

# ---------------------------------------------------------------- helpers
def decode_voice():
    raw = subprocess.run(
        ["ffmpeg", "-v", "quiet", "-i", os.path.join(ROOT, "public/audio/voiceover.m4a"),
         "-f", "f32le", "-ac", "1", "-ar", str(SR), "-"], capture_output=True, check=True).stdout
    v = np.frombuffer(raw, dtype=np.float32).astype(np.float64)
    out = np.zeros(N)
    out[: min(N, len(v))] = v[:N]
    return out

def lp(x, fc, order=2):
    b, a = signal.butter(order, min(fc, SR * 0.45) / (SR / 2), "low"); return signal.lfilter(b, a, x)
def hp(x, fc, order=2):
    b, a = signal.butter(order, fc / (SR / 2), "high"); return signal.lfilter(b, a, x)
def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi, SR * 0.45) / (SR / 2)], "band"); return signal.lfilter(b, a, x)

def noise(n=N): return rng.standard_normal(n)

def smooth_env(points, n=N):
    """piecewise-linear envelope from [(t, value), ...]"""
    ts = [p[0] for p in points]; vs = [p[1] for p in points]
    return np.interp(T[:n], ts, vs)

def place(buf, sig, t0, gain=1.0, pan=0.0):
    """add mono sig into stereo buf at time t0 with equal-power pan (-1..1)"""
    i = int(t0 * SR)
    if i >= N: return
    seg = sig[: N - i] if i >= 0 else sig
    ang = (pan + 1) * np.pi / 4
    buf[i:i + len(seg), 0] += seg * gain * np.cos(ang)
    buf[i:i + len(seg), 1] += seg * gain * np.sin(ang)

def expenv(n, tau, attack=0.002):
    t = np.arange(n) / SR
    a = np.minimum(1, t / max(attack, 1e-4))
    return a * np.exp(-t / tau)

def reverb(stereo, seconds=2.2, wet=0.25, damp=3500):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    out = np.zeros_like(stereo)
    for ch in range(2):
        ir = rng.standard_normal(n) * np.exp(-t / (seconds / 4.5))
        ir = lp(ir, damp)
        ir[: int(0.012 * SR)] *= np.linspace(0, 1, int(0.012 * SR))
        ir /= np.sqrt(np.sum(ir ** 2))
        out[:, ch] = signal.fftconvolve(stereo[:, ch], ir)[:N]
    return stereo * (1 - wet * 0.5) + out * wet

def saw(f, t):  # naive saw, band-limited later by filtering
    return 2 * ((f * t) % 1.0) - 1

# ---------------------------------------------------------------- scenes' energy curve (0..1)
ENERGY = smooth_env([(0, .9), (1.5, .6), (4.4, .7), (5.0, .85), (8, .8), (10.9, .95), (11.0, 1.0),
                     (15, 1.0), (19.1, .95), (19.2, .7), (22.8, .6), (23.0, .35), (28.5, .45),
                     (28.7, .25), (30.5, .3), (31.5, .75), (32.9, 1.0), (33.0, 1.0), (33.9, .5)])

# ================================================================= MUSIC
def make_music():
    m = np.zeros((N, 2))
    notes = {"D1": 36.71, "A1": 55.0, "D2": 73.42, "F2": 87.31, "A2": 110.0, "C3": 130.81, "D3": 146.83,
             "F3": 174.61, "A3": 220.0, "Bb1": 58.27, "G2": 98.0, "E3": 164.81}

    # --- sub drone (D1 + A1), swells with energy
    drone = np.sin(2 * np.pi * notes["D1"] * T) + 0.5 * np.sin(2 * np.pi * notes["A1"] * T) \
        + 0.15 * np.sin(2 * np.pi * notes["D1"] * 2 * T)
    drone *= 0.35 + 0.65 * ENERGY
    m[:, 0] += drone * 0.55; m[:, 1] += drone * 0.55

    # --- pad: detuned saws on Dm / Bb / Gm / Dm chord loop (4.8 s per chord), 3 filter variants cross-faded
    chords = [["D2", "A2", "D3", "F3"], ["Bb1", "F2", "D3", "F3"], ["G2", "D3", "Bb1", "A3"], ["D2", "A2", "C3", "F3"]]
    chord_len = 4.8
    pad_variants = [np.zeros(N) for _ in range(3)]
    for ci in range(int(np.ceil(DUR / chord_len))):
        t0 = ci * chord_len
        for nm in chords[ci % 4]:
            f = notes[nm]
            for det in (-0.12, 0.0, 0.12):
                ph = rng.random()
                s = saw(f * (1 + det * 0.01), T + ph / f)
                win = np.clip((T - t0) / 1.4, 0, 1) * np.clip((t0 + chord_len + 1.2 - T) / 1.2, 0, 1)
                for k, fc in enumerate((350, 1000, 2600)):
                    pad_variants[k] += lp(s, fc) * win * 0.05
    bright = np.clip(ENERGY * 1.25 - 0.1, 0, 1)
    w1 = np.clip(1 - bright * 2, 0, 1); w3 = np.clip(bright * 2 - 1, 0, 1); w2 = 1 - w1 - w3
    pad = pad_variants[0] * w1 + pad_variants[1] * w2 + pad_variants[2] * w3
    m[:, 0] += pad * 1.0; m[:, 1] += np.roll(pad, 90) * 1.0  # slight Haas widening

    # --- plucked ostinato (reactor / steam / turbine section), tempo 96 bpm
    beat = 60 / 96; step = beat / 4
    arp = ["D2", "A2", "D3", "F3", "D3", "A2", "C3", "A2"]
    def pluck(f, dur=0.35):
        n = int(dur * SR); t = np.arange(n) / SR
        s = saw(f, t) + 0.5 * saw(f * 1.005, t)
        s = lp(s, 1800) * expenv(n, 0.11)
        return s
    t = 5.0
    idx = 0
    while t < 19.1:
        sixteenth = t >= 11.0
        gain = 0.08 + 0.12 * ENERGY[int(t * SR)] if t > 5 else 0
        if sixteenth or idx % 2 == 0:
            place(m, pluck(notes[arp[idx % len(arp)]]), t, gain, pan=((idx % 5) - 2) * 0.25)
        t += step if sixteenth else step * 2
        idx += 1

    # --- percussion: deep hits at section starts
    def boom(dur=1.8, f0=90, f1=28):
        n = int(dur * SR); t = np.arange(n) / SR
        f = f1 + (f0 - f1) * np.exp(-t / 0.12)
        ph = 2 * np.pi * np.cumsum(f) / SR
        s = np.sin(ph) * expenv(n, 0.55)
        s += lp(noise(n), 400) * expenv(n, 0.15) * 0.5
        return s
    for t0, g in [(CUES["openHit"], 1.0), (CUES["cutawayStart"], 0.8), (CUES["steamStart"], 0.8),
                  (CUES["whipToBallast"], 0.7), (CUES["darkenStart"], 0.5), (CUES["finalHit"], 1.2)]:
        place(m, boom(), t0, g * 0.9)
    # steady kick on beats during build (11-19) and finale
    def kick():
        n = int(0.35 * SR); t = np.arange(n) / SR
        return np.sin(2 * np.pi * (45 + 80 * np.exp(-t / 0.03)) * t) * expenv(n, 0.12)
    tt = 11.0
    while tt < 19.0:
        place(m, kick(), tt, 0.5); tt += beat
    # finale: accelerating toms 30.6 -> 33.0
    tt = CUES["nuclearPower"]; gap = 0.5
    while tt < CUES["finalHit"] - 0.05:
        place(m, kick(), tt, 0.55 + 0.4 * (tt - 30.6) / 2.4); tt += gap; gap = max(0.16, gap * 0.9)
    # hi-hat ticks in build
    def tick():
        n = int(0.06 * SR); return hp(noise(n), 6000) * expenv(n, 0.015)
    tt = 11.0
    while tt < 19.0:
        place(m, tick(), tt + step * 2, 0.07, pan=0.4); place(m, tick(), tt + step * 3, 0.05, pan=-0.4); tt += beat

    # --- risers (noise sweeps) before big beats
    for t0, t1, g in [(3.4, 5.0, .35), (9.4, 11.0, .35), (17.4, 19.0, .3), (31.0, 33.0, .6)]:
        n = int((t1 - t0) * SR); tt = np.arange(n) / SR
        r = hp(noise(n), 300)
        r = bp(r, 400, 7000) * (tt / (t1 - t0)) ** 2.2
        place(m, r, t0, g * 0.25)
    # --- finale: lift an octave pad swell
    sw = np.zeros(N)
    for f in (notes["D2"], notes["A2"], notes["D3"], notes["F3"], notes["A3"]):
        sw += lp(saw(f, T), 1800) * 0.05
    sw *= smooth_env([(30.5, 0), (33.0, 1.0), (33.7, 0.4), (33.93, 0)])
    m[:, 0] += sw; m[:, 1] += np.roll(sw, 70)
    m = reverb(m, 2.4, 0.28)
    return m

# ================================================================= SFX
def make_sfx():
    s = np.zeros((N, 2))

    # constant bed: deep water rumble
    bed = lp(noise(), 160) * 0.05
    s[:, 0] += bed; s[:, 1] += np.roll(bed, 40)

    # propeller / shaft churn (blade-rate modulation); louder in 17.2-19.2 and finale
    rpm_hz = smooth_env([(0, 2.2), (17.0, 2.4), (18.5, 4.2), (19.5, 3.0), (28, 2.4), (33.9, 3.0)])
    ph = 2 * np.pi * np.cumsum(rpm_hz * 7) / SR           # 7 blades
    churn = lp(noise(), 260) * (0.55 + 0.45 * np.sin(ph)) * smooth_env([(0, .5), (17, .6), (18.4, 1.3), (19.5, .7), (33.9, .8)])
    s[:, 0] += churn * 0.22; s[:, 1] += churn * 0.22

    # whooshes at transitions
    def whoosh(t0, t1, f0, f1, g, pan=0.0):
        n = int((t1 - t0) * SR); tt = np.arange(n) / SR
        x = noise(n)
        fc = np.geomspace(f0, f1, n)
        # time-varying band via block filtering
        out = np.zeros(n); B = 512
        for i in range(0, n, B):
            c = fc[min(i, n - 1)]
            seg = bp(x[i:i + B + 512], c * 0.6, c * 1.5)[:min(B, n - i)] if i + 20 < n else 0
            out[i:i + len(seg)] = seg
        env = np.sin(np.pi * tt / (t1 - t0)) ** 2
        place(s, out * env, t0, g, pan)
    whoosh(4.5, 5.4, 300, 3500, 0.9)                 # hull cutaway slice
    whoosh(10.3, 11.2, 400, 2500, 0.6)
    whoosh(18.7, 20.3, 3000, 400, 1.0, 0.3)          # whip-pan to ballast
    whoosh(22.6, 23.3, 300, 1800, 0.5)
    whoosh(28.3, 29.0, 2000, 200, 0.6)

    # metallic clank / hull hit (inharmonic partials)
    def clank(t0, g=1.0, f=210):
        n = int(1.6 * SR); tt = np.arange(n) / SR
        x = sum(np.sin(2 * np.pi * f * r * tt) * a * np.exp(-tt / d) for r, a, d in
                [(1, 1, .5), (2.76, .6, .35), (5.4, .4, .2), (8.93, .25, .12)])
        x += hp(noise(n), 1500) * expenv(n, 0.02) * 0.4
        place(s, x, t0, g * 0.5)
    clank(5.0, 1.0, 190); clank(11.0, 0.8, 240); clank(CUES["whipToBallast"] + 0.4, 0.7, 150)

    # ---------- reactor (5.4-11): hum + geiger-style ticks
    hum = sum(np.sin(2 * np.pi * 60 * k * T) / k for k in (1, 2, 3, 5)) * (1 + 0.2 * np.sin(2 * np.pi * 0.7 * T))
    hum *= smooth_env([(5.0, 0), (6.5, .5), (10.9, 1.0), (11.8, .35), (19, .15), (28.7, .1), (30.6, .4), (33, .9), (33.9, 0)])
    s[:, 0] += hum * 0.035; s[:, 1] += hum * 0.035
    t = 5.6
    while t < 11.0:
        rate = 6 + 22 * (t - 5.6) / 5.4
        t += rng.exponential(1 / rate)
        n = int(0.012 * SR)
        place(s, hp(noise(n), 2500) * expenv(n, 0.003), t, 0.22, pan=rng.uniform(-.6, .6))

    # ---------- steam (11.0-19): hiss swell + pipe rumble
    n = N
    hiss = hp(noise(), 2200) * smooth_env([(10.9, 0), (11.6, 1), (13.3, .8), (13.5, 1.0), (17.0, .6), (19.0, 0)])
    s[:, 0] += hiss * 0.07; s[:, 1] += np.roll(hiss, 31) * 0.07
    # ---------- turbine whine (13.5-19): rising stack of harmonics
    tw = np.zeros(N)
    f_t = smooth_env([(13.4, 90), (15.5, 380), (17.1, 620), (19.0, 640), (19.5, 300), (22, 200)])
    amp = smooth_env([(13.4, 0), (14.0, .6), (17.1, 1.0), (19.0, .8), (19.6, .15), (22.9, 0)])
    base_ph = 2 * np.pi * np.cumsum(f_t) / SR
    for k, a in ((1, 1.0), (2, .5), (3, .3), (5, .15)):
        tw += np.sin(k * base_ph + 0.4 * np.sin(2 * np.pi * 5.5 * T)) * a
    tw = lp(tw, 5000) * amp
    s[:, 0] += tw * 0.05; s[:, 1] += tw * 0.05

    # ---------- ballast (19.4-22.8)
    def air_vent(t0, dur, g, pan):
        n = int(dur * SR); tt = np.arange(n) / SR
        x = bp(noise(n), 1800, 9000) * (np.minimum(1, tt / .05)) * np.exp(-tt / (dur * .55))
        place(s, x, t0, g, pan)
    for k, tv in enumerate((CUES["ventOpen"], CUES["ventOpen"] + 0.22, CUES["ventOpen"] + 0.45)):
        air_vent(tv, 1.6, 0.55, (-0.4, 0.0, 0.4)[k])
    # flood gurgle: bandpassed noise + bubble chirps
    gur = bp(noise(), 120, 900) * smooth_env([(19.7, 0), (20.3, 1), (22.0, .8), (22.9, 0)])
    gur *= 0.6 + 0.4 * np.sin(2 * np.pi * 7 * T + np.cumsum(rng.standard_normal(N)) * 0.0004)
    s[:, 0] += gur * 0.16; s[:, 1] += np.roll(gur, 50) * 0.16
    tt0 = 19.9
    while tt0 < 22.6:
        tt0 += rng.exponential(0.045)
        n = int(0.05 * SR); q = np.arange(n) / SR; f0 = rng.uniform(350, 900)
        pop = np.sin(2 * np.pi * (f0 + 2600 * q) * q) * expenv(n, 0.015, 0.001)
        place(s, pop, tt0, 0.1, rng.uniform(-.7, .7))
    # hull groan during the dive
    n = int(2.8 * SR); q = np.arange(n) / SR
    gf = 72 - 14 * q / 2.8 + 3 * np.sin(2 * np.pi * 3 * q)
    gr = np.sin(2 * np.pi * np.cumsum(gf) / SR) + 0.5 * np.sin(4 * np.pi * np.cumsum(gf) / SR)
    gr *= np.sin(np.pi * q / 2.8) ** 2
    place(s, gr, 20.4, 0.25)

    # ---------- sonar pings (visual rings spawn on the same cue times) + echoes
    def ping(t0, g, f=1180):
        n = int(2.4 * SR); q = np.arange(n) / SR
        x = np.sin(2 * np.pi * f * q) * expenv(n, 0.55, 0.004) + 0.3 * np.sin(2 * np.pi * f * 2.0 * q) * expenv(n, 0.25)
        place(s, x, t0, g, 0.0)
        e = lp(x, 1800)
        place(s, e, t0 + 1.15, g * 0.28, -0.5); place(s, e, t0 + 1.55, g * 0.14, 0.5)
    for i, tp in enumerate(CUES["sonarPings"]):
        ping(tp, 0.38 - i * 0.02)
    # tiny sonar "blip" tail clicks for the last ping hits rocks
    for tp in (24.6, 25.2, 26.1, 26.7):
        n = int(0.05 * SR); q = np.arange(n) / SR
        place(s, np.sin(2 * np.pi * 2400 * q) * expenv(n, 0.012), tp, 0.06, rng.uniform(-.5, .5))

    # ---------- finale: heartbeat thuds (30.6+) and final impact with long tail
    def thud(t0, g):
        n = int(0.5 * SR); q = np.arange(n) / SR
        x = np.sin(2 * np.pi * (38 + 40 * np.exp(-q / 0.04)) * q) * expenv(n, 0.14)
        place(s, x, t0, g)
    tt = CUES["nuclearPower"]
    while tt < 32.9:
        thud(tt, 0.35); thud(tt + 0.22, 0.22); tt += 0.8
    n = int(3.0 * SR); q = np.arange(n) / SR
    imp = np.sin(2 * np.pi * (28 + 70 * np.exp(-q / 0.1)) * q) * expenv(n, 0.8) + lp(noise(n), 700) * expenv(n, 0.35) * 0.6
    place(s, imp, CUES["finalHit"], 0.9)
    clank(CUES["finalHit"] + 0.02, 0.7, 120)
    # opening boom hit
    place(s, imp[: int(2 * SR)], CUES["openHit"], 0.7)

    s = reverb(s, 1.8, 0.18)
    return s

# ================================================================= MIX
def sidechain_env(v):
    """voice activity 0..1 with fast attack / slow release"""
    e = np.abs(v)
    e = lp(e, 12, 1)
    e = e / (np.percentile(e, 98) + 1e-9)
    e = np.clip(e * 1.6, 0, 1)
    out = np.zeros_like(e); y = 0.0
    a_att = 1 - np.exp(-1 / (0.035 * SR)); a_rel = 1 - np.exp(-1 / (0.45 * SR))
    for i, x in enumerate(e):
        y += (a_att if x > y else a_rel) * (x - y)
        out[i] = y
    return out

def rms_db(x): return 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-12)
def peak_db(x): return 20 * np.log10(np.max(np.abs(x)) + 1e-12)

def write_wav(path, st):
    pcm = (np.clip(st, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

def main():
    voice = decode_voice()
    duck = sidechain_env(voice)
    music = make_music(); sfx = make_sfx()

    music_gain_open = 1.0   # when voice is silent (intro/outro tails)
    music_gain_speech = 10 ** (-11 / 20)  # ducked by 11 dB under speech
    mg = music_gain_open + (music_gain_speech - music_gain_open) * duck
    sg = 1.0 + (10 ** (-4 / 20) - 1.0) * duck
    music *= mg[:, None]; sfx *= sg[:, None]

    # loudness staging relative to the voice: ducked music ~ -15 dB below voice RMS, sfx ~ -16 dB
    speech_mask = duck > 0.6
    v_rms = rms_db(voice[speech_mask])
    m_rms = rms_db(music[speech_mask]); s_rms = rms_db(sfx[speech_mask])
    music *= 10 ** ((v_rms - 15 - m_rms) / 20)
    sfx *= 10 ** ((v_rms - 16 - s_rms) / 20)

    # safety: soft limiter per bus, then verify summed peak
    music = np.tanh(music * 1.0)
    sfx = np.tanh(sfx * 1.0)
    VOICE_GAIN = 0.75   # supplied voice peaks at 0 dBFS; -2.5 dB gives headroom (mirrored in src/Video.tsx)
    mix = voice[:, None] * VOICE_GAIN + music + sfx
    pk = peak_db(mix)
    if pk > -1.0:   # voice is never touched further; only music/sfx come down until the sum is safe
        for _ in range(60):
            music *= 0.97; sfx *= 0.97
            if peak_db(voice[:, None] * VOICE_GAIN + music + sfx) <= -1.0: break
        mix = voice[:, None] * VOICE_GAIN + music + sfx
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    write_wav(os.path.join(ROOT, "public/audio/music.wav"), music)
    write_wav(os.path.join(ROOT, "public/audio/sfx.wav"), sfx)
    write_wav(os.path.join(ROOT, "reports/mix_preview.wav"), mix)

    report = {
        "duration_s": round(DUR, 3),
        "voice_gain": VOICE_GAIN, "voice_rms_db_speech": round(rms_db(voice[speech_mask] * VOICE_GAIN), 2),
        "music_rms_db_under_speech": round(rms_db(music[speech_mask]), 2),
        "sfx_rms_db_under_speech": round(rms_db(sfx[speech_mask]), 2),
        "voice_minus_music_db": round(rms_db(voice[speech_mask] * VOICE_GAIN) - rms_db(music[speech_mask]), 2),
        "voice_minus_sfx_db": round(rms_db(voice[speech_mask] * VOICE_GAIN) - rms_db(sfx[speech_mask]), 2),
        "music_peak_db": round(peak_db(music), 2), "sfx_peak_db": round(peak_db(sfx), 2),
        "summed_mix_peak_db": round(peak_db(mix), 2),
        "clipped_samples": int(np.sum(np.abs(mix) >= 0.999)),
    }
    json.dump(report, open(os.path.join(ROOT, "reports/audio_report.json"), "w"), indent=2)
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
